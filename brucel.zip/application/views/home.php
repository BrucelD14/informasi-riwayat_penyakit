<div class="card-box pd-20 height-100-p mb-30">
				<div class="row align-items-center">
					<div class="col-md-3">
						<img src="<?php echo base_url() ?>assets/vendors/images/banner-img.png" alt="">
					</div>
					<div class="col-md-8">
						<h4 class="font-20 weight-500 mb-10 text-capitalize">
						  <div class="weight-600 font-30 text-blue">Hi, <?php echo $this->session->userdata('nama') ?>!</div><small>(<?php echo $this->session->userdata('level') ?>)</small>
						</h4>
						<p class="font-18 max-width-600">Have an nice day. Lakukan yang terbaik hari ini, karena hari ini lebih baik dari hari kemarin!!</p>
					</div>
				</div>
			</div>